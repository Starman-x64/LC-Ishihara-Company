## v1.1.0
- Doors which spawn closed now appear magenta.
- Fixed mismatched version numbers throughout files.
- Added "Known Issues" section.

## v1.0.0
- Release.